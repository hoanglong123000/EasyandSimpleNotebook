﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notebook
{
    public partial class UpNote : Form
    {
        public UpNote()
        {
            InitializeComponent();
        }

        private void returnaddscrnbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            
        }

        private void Updescripbox_TextChanged(object sender, EventArgs e)
        {
            if (this.Updescripbox.Text.ToString() != "")
            {
                this.Upnotebtn.Enabled = true;
            }
        }

        private void Boldswitch(bool swit)
        {
            if (true)
            {
                this.Updescripbox.Font = new Font(this.Updescripbox.Font.FontFamily, this.Updescripbox.Font.Size, FontStyle.Bold);
                this.Uptitlebox.Font = new Font(this.Uptitlebox.Font.FontFamily, this.Uptitlebox.Font.Size, FontStyle.Bold);
            }
            else if (false)
            {
                this.Updescripbox.Font = new Font(this.Updescripbox.Font.FontFamily, this.Updescripbox.Font.Size, FontStyle.Regular);
                this.Uptitlebox.Font = new Font(this.Uptitlebox.Font.FontFamily, this.Uptitlebox.Font.Size, FontStyle.Regular);
            }
        }

        private void ItalicSwitch(bool i)
        {
            if (true)
            {
                this.Updescripbox.Font = new Font(this.Updescripbox.Font.FontFamily, this.Updescripbox.Font.Size, FontStyle.Italic);
                this.Uptitlebox.Font = new Font(this.Uptitlebox.Font.FontFamily, this.Uptitlebox.Font.Size, FontStyle.Italic);
            }
            else if (false)
            {
                this.Updescripbox.Font = new Font(this.Updescripbox.Font.FontFamily, this.Updescripbox.Font.Size, FontStyle.Regular);
                this.Uptitlebox.Font = new Font(this.Uptitlebox.Font.FontFamily, this.Uptitlebox.Font.Size, FontStyle.Regular);
            }
        }



        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void Uptitlebox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
